package com.ubu.p3.twentyonepilots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwentyOnePilotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwentyOnePilotsApplication.class, args);
	}

}


